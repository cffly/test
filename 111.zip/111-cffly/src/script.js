var count = 0;
    var counterElement = document.getElementById("counter");

    function increment() {
      count+=2;
      counterElement.textContent = count;}

document.write("HELLO我是冷霏霏 ")